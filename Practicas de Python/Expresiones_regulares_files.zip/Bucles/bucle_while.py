contador = 0

#Mientras que la condición se cumpla, el bucle se va a seguir ejecutando 
#(vuelta, tras vuelta se verifica la condición)
while contador < 16:
    contador += 1
    print(contador)
    
else:
    print("El bucle llego a su fin")