numeros = [1,2,3,5,7,11]

#Encontrando el número mayor de una lista
numero_mayor = max(numeros)

#Encontrando el número menor de una lista
numero_menor = min(numeros)

#Redondeando a 6 decimales
redondear_número = round(12.3456789,3)

#Retorna False -> 0, vacio, False, none/ True -> distinto de 0, True, cadena, datos no vacios 
resultado_bool = bool([])

#Retorna True si todos los valores son verdaderos 
resultado_all = all(["Vanessa", 52, True, False])

#Suma todos los valores de un iterable
Suma = sum(numeros)

print(Suma)