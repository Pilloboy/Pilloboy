#Creando los datos
lista = list(["Leonel","Vanessa", 16])
tupla = tuple(["Leonel","Vanessa", 16])

#El conjunto se puede desempaquetar pero como se re ordena los elementos pues no tendras idea de que elemento estas pidiendo que te ofrezca
conjuntos = set(["Leonel","Vanessa", 16])

#Desempaquetado
nombre,novia,edad = lista

#Mostrando resultados
print(novia)