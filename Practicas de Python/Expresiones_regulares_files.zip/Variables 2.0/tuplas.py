#Creando tupla con tuple()
tupla = tuple(["Leonel","Vanessa", 16,])

#Creando tupla sin parentesis de multiples datos
tupla = "Leonel","Vanessa", 16

#Creando una tupla sin parentesis con un solo dato
tupla = "Leonel",

print(tupla)
