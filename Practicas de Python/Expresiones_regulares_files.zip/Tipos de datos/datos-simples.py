string="una unica linea"
string="""multiples 
                lineas"""

Int=32
Float=98.425

booleano=True
booleano=False
                