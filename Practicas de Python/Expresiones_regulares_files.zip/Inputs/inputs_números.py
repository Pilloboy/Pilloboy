#Pedirle un número al usuario
número = input("Dame tu número: ")

#Convierto el número a entero y lo multiplicando por 2
#resultado_entero = int(número) * 2

#Convierto el número a flotante y lo multiplicando por 2
resultado_flotante = float(número) * 2

#Mostrando el resultado
print(resultado_flotante)