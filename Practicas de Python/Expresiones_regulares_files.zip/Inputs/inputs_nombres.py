#Pedirle un dato al usuario
nombre = input("Makina, dame tu nombre: ")

#Mostrando el nombre
print(f"El nombre es: {nombre}")