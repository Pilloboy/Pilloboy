import pandas as pd

Archivo = pd.read_csv("Archivos\\Datos.csv")

print(Archivo)
