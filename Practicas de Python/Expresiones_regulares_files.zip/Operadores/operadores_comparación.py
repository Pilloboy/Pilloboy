igual_que = 5 == 6

distinto_de = 5 != 6

mayor_que = 5 > 6

menor_que = 5 < 6

mayor_o_igual_que= 5 >= 6

menor_o_igual_que = 5<= 6

#Calculos_combinados
a = 5
b = 10
c = 20

Comparación = a + b < c

#Comparar contraseñas
contraseña_almacenada = "Leonel"
contraseña_escrita = "Leonel"

print(contraseña_almacenada == contraseña_escrita)