#AND

Resultado = True & True #Devolver True
Resultado2 = False & True #Devolver False
Resultado3 = True & False #Devolver False
Resultado4 = False & False #Devolver False

#OR

Resultado5 = True | True #Devolver True
Resultado6 = False | True #Devolver True
Resultado7 = True | False #Devolver True
Resultado8 = False | False #Devolver False

#NOT

Resultado9 = not True #Devolver False
Resultado10 = not False #Devolver True 

print(Resultado10)