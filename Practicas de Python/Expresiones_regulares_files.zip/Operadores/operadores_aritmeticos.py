#Suma y resta (+ y -)
Suma=12+5
Resta=12-5

#Multi y división (* y /)
Multi=12*5
División=12/6 #Devuelve un dato float (flotante)

#Potenciación (exponente) (**)
Exponente=12**5

#División baja (//)
División_baja=12//5 #Devuelve un entero redondeado hacia abajo

#Resto o módulo
Resto=12 % 7

#Typev(dato) nos devuele que tipo de dato es
Tipo_de_dato=type(División)

print(Tipo_de_dato)
