import Paquete.saludar 

print(Paquete.__path__)
print(Paquete.saludar.saludar("Leonel"))