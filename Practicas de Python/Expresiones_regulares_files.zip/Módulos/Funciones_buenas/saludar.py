def saludar(nombre):
    return f"Hola {nombre}, espero hayas tenido un maravilloso día"


def saludar_raro(name):
    return f"Konda {name}, espero hayas tenido un día nashe, anasheli anashei"


print(__name__)
