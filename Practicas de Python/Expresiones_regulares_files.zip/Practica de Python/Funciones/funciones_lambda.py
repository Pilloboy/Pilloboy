#Creando una funcióbn lambda para multiplicar por dos
multiplicar_por_dos = lambda x : x*2

print(multiplicar_por_dos(5))