#Creando los datos
lista = list (["Leonel", "Torres Rodríguez", 16])
tupla = tuple (["Leonel", "Torres Rodríguez", 16])
#El cojunto se puede desempaquetar pero como re ordena los elementos pues no tendras idea de que elemento estas pidiendo que te ofrezca
conjunto = set (["Leonel", "Torres Rodríguez", 16])

#Desempaquetado
nombre,apellido,edad = lista

#Mostrando resultados
print(apellido)
