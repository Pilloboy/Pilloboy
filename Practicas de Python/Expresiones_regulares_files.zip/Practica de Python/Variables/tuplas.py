#Creando tuplas con tuple()
tupla = tuple(["Leonel", "Torres Rodríguez", 16])

#Creando una tupla sin parentesis
tupla = "Leonel","Torres Rodríguez","16"

#Creando una tupla sin parentesis de un solo dato 
tupla = "Leonel",

print(type(tupla))