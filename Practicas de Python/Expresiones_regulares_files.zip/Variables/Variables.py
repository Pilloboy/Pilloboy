#Definiendo una variable con camelCase
nombreCompleto="Rigoberto Jaciel Martinez Madriz"

#Definiendo una variable con snake_case
nombre_completo="Rigoberto Jaciel Martinez Madriz"

#Concatenar con +
bienvenida= "Hola " +nombreCompleto+ " ¿Cómo estas?"

#Concatenar con f-strings
bienvenida =f"Hola {nombre_completo} ¿Cómo estas?"

#operador para eliminar declaraciones (del)
del bienvenida 

#operadores de pertenencia (in /not in)
print("Rigo"in bienvenida)#True
print("Rigo"not in bienvenida)#False
