contraseña_almacenada = "Leonel"
contraseña_escrita = "Leonel"

if contraseña_almacenada == contraseña_escrita:
    print("Iniciando sesión")
    #print("Forma parte del if")
else: 
    print("Contraseña equivocada, inserte de nuevo")
    #print("Forma parte del else")
        